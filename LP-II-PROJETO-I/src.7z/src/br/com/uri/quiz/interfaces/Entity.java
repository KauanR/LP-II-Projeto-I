package br.com.uri.quiz.interfaces;

public interface Entity {

	void readData();
	void writeData();

}
